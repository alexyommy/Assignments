//Print odds 1-20
for(let i=0; i<=20; i++) {
    if(i % 2 == 1) {
        console.log(i);
    }
}

//Sum and Print 1-5
let sum=0;
for(let i=1; i<=5; i++) {
    sum+=i
    console.log("Num:", i, "Sum:", sum);
} 